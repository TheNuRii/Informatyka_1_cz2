#include <iostream>
#include "polynominal.h"
using namespace std;

Polynominal::Polynominal(){}
Polynominal::Polynominal(const Polynominal &p){
    for (auto itr = p.terms_.begin(); itr != p.terms_.end(); ++itr)
        if( (*itr).coef_!=0 ) terms_.push_back(*itr);
}
Polynominal::Polynominal( const Term<int> &t ){
    if( t.coef_!=0) terms_.push_front(t);
}
Polynominal::Polynominal(const int coef){
   if(coef!=0) terms_.push_front(Term<int>(coef));
}
Polynominal::Polynominal(const int coef, const int pow){
    if( coef!=0) terms_.push_front(Term<int>(coef, pow));
}

void Polynominal::operator =(const Polynominal &right){
    if( !terms_.empty() ) terms_.clear();
    for (auto itr = right.terms_.begin(); itr != right.terms_.end(); ++itr)
        if( (*itr).coef_!=0 ) terms_.push_back(*itr);
}

ostream & operator<<(ostream &out, const Polynominal &p){
    for(auto itr{ p.terms_.begin() }; itr!=p.terms_.end();  ){
        //out<<" ";
        if( itr==p.terms_.begin()){
            if((*itr).coef_>0) out<<" "; else out<<" -";
        }    
        if( abs((*itr).coef_)!=1 || ((*itr).pow_)==0) out<<abs((*itr).coef_);
        if( (*itr).pow_!=0 ) out<<"x";
        if( (*itr).pow_>1 || (*itr).pow_<0 ) out<<"^"<<(*itr).pow_;

        itr++;
        if(itr!=p.terms_.end()) {
            if((*itr).coef_>0) out<<" +";
            else out<<" -";
        }    
    }
    return out;
}


//***************************************************************************** */
//   Metody poniżej są przeznaczone do uzupełnienia przez studentów podczas zajęć
//***************************************************************************** */
void Polynominal::operator+=( const Polynominal &right ){
}

void Polynominal::operator *=(const Term<int> &right){
}

Polynominal operator +(const Polynominal &left, const Polynominal &right){
}

Polynominal operator *(const Polynominal &left, const Term<int> &right){
}

Polynominal operator* (const Polynominal &left, const Polynominal &right){
}
